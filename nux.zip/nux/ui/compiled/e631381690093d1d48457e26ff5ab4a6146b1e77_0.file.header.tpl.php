<?php
/* Smarty version 4.5.3, created on 2026-09-02 03:32:36
  from '/home/isplzepc/public_html/nux/ui/ui/sections/header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_6a9736646c1c01_15675605',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e631381690093d1d48457e26ff5ab4a6146b1e77' => 
    array (
      0 => '/home/isplzepc/public_html/nux/ui/ui/sections/header.tpl',
      1 => 1786009162,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:admin/header.tpl' => 1,
  ),
),false)) {
function content_6a9736646c1c01_15675605 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:admin/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
