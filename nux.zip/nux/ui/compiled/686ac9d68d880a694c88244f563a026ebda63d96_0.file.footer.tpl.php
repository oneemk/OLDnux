<?php
/* Smarty version 4.5.3, created on 2026-09-02 03:32:36
  from '/home/isplzepc/public_html/nux/ui/ui/sections/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_6a973664756586_37332867',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '686ac9d68d880a694c88244f563a026ebda63d96' => 
    array (
      0 => '/home/isplzepc/public_html/nux/ui/ui/sections/footer.tpl',
      1 => 1786009162,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:admin/footer.tpl' => 1,
  ),
),false)) {
function content_6a973664756586_37332867 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:admin/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
