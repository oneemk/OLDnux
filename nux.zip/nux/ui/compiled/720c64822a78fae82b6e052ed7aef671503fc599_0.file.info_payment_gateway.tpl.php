<?php
/* Smarty version 4.5.3, created on 2026-09-02 03:32:36
  from '/home/isplzepc/public_html/nux/ui/ui/widget/info_payment_gateway.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_6a973664651d60_95793670',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '720c64822a78fae82b6e052ed7aef671503fc599' => 
    array (
      0 => '/home/isplzepc/public_html/nux/ui/ui/widget/info_payment_gateway.tpl',
      1 => 1786009162,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6a973664651d60_95793670 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="panel panel-success panel-hovered mb20 activities">
    <div class="panel-heading"><?php echo Lang::T('Payment Gateway');?>
: <?php echo str_replace(',',', ',$_smarty_tpl->tpl_vars['_c']->value['payment_gateway']);?>

    </div>
</div><?php }
}
